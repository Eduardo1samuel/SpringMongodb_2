package com.SMongodb.spring_boot_starter_mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootStarterMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
