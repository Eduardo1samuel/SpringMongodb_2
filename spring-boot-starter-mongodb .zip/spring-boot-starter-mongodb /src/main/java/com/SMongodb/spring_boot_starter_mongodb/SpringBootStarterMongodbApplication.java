package com.SMongodb.spring_boot_starter_mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootStarterMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootStarterMongodbApplication.class, args);
	}

}
